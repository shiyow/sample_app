# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '763a949c401253bbcbce0b02cd22919b3e18a0e9abd2369953f73cc69453ded05773827eac63e84c4c379b289fbff4181f50e321b3b3a62a33f0bc8326e3c023'